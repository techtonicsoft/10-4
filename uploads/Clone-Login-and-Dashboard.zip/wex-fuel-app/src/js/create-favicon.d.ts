declare function createFavicon(): void;
export default createFavicon;
