// This script is used to create a simple 10-4 by WEX favicon
// It draws the text "10-4" in white on a red background
// We're using a canvas to generate the favicon dynamically

function createFavicon() {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');

  // Background
  ctx.fillStyle = '#e31937'; // WEX red
  ctx.fillRect(0, 0, 64, 64);

  // Text
  ctx.fillStyle = 'white';
  ctx.font = 'bold 28px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('10-4', 32, 32);

  // Create favicon link element
  const link = document.createElement('link');
  link.type = 'image/x-icon';
  link.rel = 'shortcut icon';
  link.href = canvas.toDataURL('image/x-icon');

  // Remove existing favicon
  const existingFavicon = document.querySelector('link[rel="shortcut icon"]');
  if (existingFavicon) {
    document.head.removeChild(existingFavicon);
  }

  // Add new favicon
  document.head.appendChild(link);
}

export default createFavicon;
