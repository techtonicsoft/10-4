// Import CSS
import './css/styles.css';
// Import favicon generator
import createFavicon from './js/create-favicon';

document.addEventListener('DOMContentLoaded', () => {
  const root = document.querySelector('#root');
  if (!root) return;

  // Create favicon
  createFavicon();

  // Initial page load (show login page by default)
  loadPage('login');

  // Handle navigation
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;
    const navItem = target.closest('.nav-item');

    if (navItem) {
      e.preventDefault();
      const page = navItem.getAttribute('data-page');
      if (page) {
        loadPage(page);
        updateActiveNavItem(page);
      }
    }

    // Handle login button click
    if (target.closest('#login-button')) {
      e.preventDefault();
      loadPage('dashboard');
    }

    // Handle find fuel buttons
    if (target.closest('.find-fuel-button')) {
      e.preventDefault();
      loadPage('find-fuel');
      updateActiveNavItem('find-fuel');
    }

    // Handle error page home button
    if (target.closest('.homepage-button')) {
      e.preventDefault();
      loadPage('dashboard');
    }
  });
});

function loadPage(page: string) {
  const root = document.querySelector('#root');
  if (!root) return;

  switch (page) {
    case 'login':
      root.innerHTML = renderLoginPage();
      break;
    case 'dashboard':
      root.innerHTML = renderDashboardPage();
      break;
    case 'find-fuel':
      root.innerHTML = renderFindFuelPage();
      break;
    case 'transactions':
      root.innerHTML = renderTransactionsPage();
      break;
    case 'more':
      root.innerHTML = renderMorePage();
      break;
    case 'error':
      root.innerHTML = renderErrorPage();
      break;
    default:
      root.innerHTML = renderLoginPage();
  }
}

function updateActiveNavItem(page: string) {
  const navItems = document.querySelectorAll('.nav-item');
  for (const item of navItems) {
    if (item.getAttribute('data-page') === page) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  }
}

// Render functions for each page
function renderStatusBar() {
  return `
    <div class="status-bar">
      <div class="time">3:28 AM</div>
      <div class="indicators">
        <span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5Z" stroke="white" stroke-width="1.5"/>
            <path d="M3.5 12H7.5M16.5 12H20.5M12 3.5V7.5M12 16.5V20.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </span>
        <span>Vo LTE</span>
        <span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 19.5H6M10.5 19.5H21M3 12H10.5M15 12H21M3 4.5H15M19.5 4.5H21" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </span>
        <span>13.9 K/S</span>
        <span>35%</span>
      </div>
    </div>
  `;
}

function renderBottomNav(activePage = '') {
  return `
    <div class="bottom-nav">
      <a href="#" class="nav-item ${activePage === 'dashboard' ? 'active' : ''}" data-page="dashboard">
        <span class="nav-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/>
            <path d="M12 7V12L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </span>
        <span>Dashboard</span>
      </a>
      <a href="#" class="nav-item ${activePage === 'find-fuel' ? 'active' : ''}" data-page="find-fuel">
        <span class="nav-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 6C16 8.20914 14.2091 10 12 10C9.79086 10 8 8.20914 8 6C8 3.79086 9.79086 2 12 2C14.2091 2 16 3.79086 16 6Z" stroke="currentColor" stroke-width="2"/>
            <path d="M6 21V19C6 15.6863 8.68629 13 12 13C15.3137 13 18 15.6863 18 19V21H6Z" stroke="currentColor" stroke-width="2"/>
          </svg>
        </span>
        <span>Find Fuel</span>
      </a>
      <a href="#" class="nav-item ${activePage === 'transactions' ? 'active' : ''}" data-page="transactions">
        <span class="nav-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
            <path d="M9 12H15M9 8H15M9 16H13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </span>
        <span>Transactions</span>
      </a>
      <a href="#" class="nav-item ${activePage === 'more' ? 'active' : ''}" data-page="more">
        <span class="nav-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 6H20M4 12H20M4 18H16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </span>
        <span>More</span>
      </a>
    </div>
  `;
}

function renderLoginPage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="login-container">
        <div class="login-logo">
          <img src="/images/10-4-logo.png" alt="10-4 by WEX" style="width: 100%">
        </div>
        <div class="login-form">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" value="Nerlansalbaje1231@gmail.com">
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <div class="password-field">
              <input type="password" id="password" value="@Nicole2018">
              <button class="password-toggle">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 12C2 12 5.5 5 12 5C18.5 5 22 12 22 12C22 12 18.5 19 12 19C5.5 19 2 12 2 12Z" stroke="currentColor" stroke-width="2"/>
                  <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
                  <path d="M3 21L21 3" stroke="currentColor" stroke-width="2"/>
                </svg>
              </button>
            </div>
          </div>
          <a href="#" class="forgot-password">Forgot password?</a>
          <div class="checkbox-container">
            <input type="checkbox" id="keep-logged" checked>
            <label for="keep-logged">Keep me logged in</label>
          </div>
          <button id="login-button" class="login-button">
            <span>Log in</span>
            <span>→</span>
          </button>
          <p class="signup-text">Don't have an account? <a href="#">Get started</a></p>
        </div>
      </div>
    </div>
  `;
}

function renderDashboardPage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="dashboard">
        <div class="special-offer">
          <span class="tag-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.5 5H16.5M7.5 5C6.11929 5 5 6.11929 5 7.5V19C5 20.3807 6.11929 21.5 7.5 21.5H16.5C17.8807 21.5 19 20.3807 19 19V7.5C19 6.11929 17.8807 5 16.5 5M7.5 5C7.5 3.61929 8.61929 2.5 10 2.5H14C15.3807 2.5 16.5 3.61929 16.5 5" stroke="#1ab394" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M9 12L11 14L15 10" stroke="#1ab394" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
          <div class="offer-text">
            <strong>Special offer</strong>
            <span>Save an additional $20 on your first transaction of 75 gallons or more!</span>
          </div>
        </div>

        <div class="user-card">
          <div class="user-header">
            <div class="user-avatar">NS</div>
            <div class="user-greeting">
              <span class="greeting-text">Good morning</span>
              <span class="user-name">Nerlan Sanchez</span>
            </div>
          </div>

          <div class="user-stats">
            <div class="stat-box">
              <div class="stat-label">Total savings</div>
              <div class="stat-value">$0.00</div>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-box">
              <div class="stat-label">Fill ups</div>
              <div class="stat-value">0</div>
            </div>
          </div>
        </div>

        <div class="rewards-card">
          <h3 class="rewards-title">Unlock May bonus</h3>
          <div class="rewards-points">0</div>
          <div class="rewards-subtitle">Reward points</div>
          <div class="rewards-progress-text">
            <span>500 points to Bronze</span>
            <span>1 gallon = 1 point</span>
          </div>
          <div class="rewards-progress-bar">
            <div class="rewards-progress-fill"></div>
          </div>
          <div class="rewards-milestones">
            <div class="milestone">
              <div class="milestone-mark"></div>
              <div class="milestone-value">150</div>
            </div>
            <div class="milestone">
              <div class="milestone-mark"></div>
              <div class="milestone-value">250</div>
            </div>
            <div class="milestone">
              <div class="milestone-mark"></div>
              <div class="milestone-value">400</div>
            </div>
            <div class="milestone">
              <div class="milestone-trophy">🏆</div>
              <div class="milestone-value">500</div>
            </div>
            <div class="milestone">
              <div class="milestone-mark"></div>
              <div class="milestone-value">750</div>
            </div>
            <div class="milestone">
              <div class="milestone-trophy silver">🏆</div>
              <div class="milestone-value">1250</div>
            </div>
            <div class="milestone">
              <div class="milestone-trophy">🏆</div>
              <div class="milestone-value"></div>
            </div>
          </div>
        </div>

        <div class="invite-section">
          <h3 class="invite-title">Get 250 points</h3>
          <p class="invite-subtitle">by inviting a friend to join 10-4 by WEX</p>
          <button class="invite-button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 5V19M5 12H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            Invite a Friend
          </button>
        </div>
      </div>
      ${renderBottomNav('dashboard')}
    </div>
  `;
}

function renderFindFuelPage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="find-fuel-page">
        <div class="map-container">
          <div class="map-overlay">
            <div class="map-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="black" stroke-width="2"/>
                <path d="M12 8V16M8 12H16" stroke="black" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <div class="map-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 21L10 14M14 10L21 3M21 3H14M21 3V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="loading-message">
            <span class="loading-spinner"></span>
            <span>Loading stations within 100 miles...</span>
          </div>

          <div class="no-stations">0 STATIONS IN THIS AREA</div>

          <div class="search-bar">
            <div class="search-input">
              <span class="search-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="11" cy="11" r="7" stroke="#aaa" stroke-width="2"/>
                  <path d="M16 16L20 20" stroke="#aaa" stroke-width="2" stroke-linecap="round"/>
                </svg>
              </span>
              <span class="search-text">Current location</span>
            </div>
            <div class="route-button">
              <span class="route-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 10L21 3L14 21L10 13L3 10Z" stroke="white" stroke-width="2" stroke-linejoin="round"/>
                </svg>
              </span>
              <span>Route</span>
            </div>
          </div>
        </div>
      </div>
      ${renderBottomNav('find-fuel')}
    </div>
  `;
}

function renderTransactionsPage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="transactions-container">
        <div class="transactions-icon">$</div>
        <h2 class="transactions-title">No transactions yet</h2>
        <p class="transactions-subtitle">Transaction receipts will appear here after fueling up</p>
        <button class="find-fuel-button">Find fuel</button>
      </div>
      ${renderBottomNav('transactions')}
    </div>
  `;
}

function renderMorePage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="more-page">
        <h1 class="page-title">More</h1>

        <div class="profile-section">
          <div class="profile-avatar">NS</div>
          <div class="profile-name">Nerlan Sanchez</div>
          <div class="chevron-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-header">MANAGE</div>

          <div class="settings-item">
            <div>Notifications</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="settings-item">
            <div>Payment methods</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="settings-item">
            <div>Fingerprint authentication</div>
            <label class="toggle-switch">
              <input type="checkbox">
              <span class="slider"></span>
            </label>
          </div>

          <div class="settings-item">
            <div>Rewards</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="settings-item">
            <div>Invite a Friend</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-item">
            <div>Client Id</div>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-header">ABOUT</div>

          <div class="settings-item">
            <div>Terms and Conditions</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="settings-item">
            <div>Privacy Policy</div>
            <div class="chevron-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#aaa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="app-version">
            <div>App version</div>
            <div>1.0.24 20250219.3</div>
          </div>
        </div>

        <a href="#" class="logout-button">Log out</a>
      </div>
      ${renderBottomNav('more')}
    </div>
  `;
}

function renderErrorPage() {
  return `
    ${renderStatusBar()}
    <div class="app-container">
      <div class="error-container">
        <img src="/images/10-4-logo.png" alt="WEX" class="error-logo">
        <div class="error-code">403</div>
        <h1 class="error-title">Access Forbidden</h1>
        <p class="error-message">You don't have permission to access this page.</p>
        <button class="homepage-button">Go to Homepage</button>
      </div>
    </div>
  `;
}
